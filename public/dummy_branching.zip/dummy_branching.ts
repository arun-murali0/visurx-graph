// dummy_branching.ts — exercises stage3 CFG: functions with real branches,
// loops, try/catch, and one straight-line function as a control.

function straightLine(a: number, b: number): number {
  const sum = a + b;
  return sum;
}

function withIfElse(user: { active: boolean; name: string }): string {
  if (user.active) {
    return `Hello, ${user.name}!`;
  } else {
    return `Welcome back, ${user.name}.`;
  }
}

function withMultipleBranches(status: number): string {
  if (status === 200) {
    return "OK";
  } else if (status === 404) {
    return "Not Found";
  } else if (status === 500) {
    return "Server Error";
  } else {
    return "Unknown";
  }
}

function withLoop(items: string[]): number {
  let count = 0;
  for (const item of items) {
    if (item.length > 0) {
      count++;
    }
  }
  return count;
}

async function withTryCatch(url: string): Promise<string | null> {
  try {
    const res = await fetch(url);
    return await res.text();
  } catch (err) {
    console.error(err);
    return null;
  }
}

class Validator {
  check(value: number): boolean {
    if (value < 0) {
      return false;
    }
    if (value > 100) {
      return false;
    }
    return true;
  }
}

export { straightLine, withIfElse, withMultipleBranches, withLoop, withTryCatch, Validator };
